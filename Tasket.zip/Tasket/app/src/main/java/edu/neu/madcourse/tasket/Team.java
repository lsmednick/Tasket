package edu.neu.madcourse.tasket;

import com.bignerdranch.expandablerecyclerview.Model.ParentObject;

import java.util.List;

public class Team implements ParentObject {

    private String teamName;
    private List<Object> subteamList;

    public Team(String name){
        this.teamName = name;

    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String name){
         this.teamName = name;
    }

    @Override
    public List<Object> getChildObjectList(){
        return subteamList;
    }

    @Override
    public void setChildObjectList(List<Object> list){
        subteamList = list;
    }
}
