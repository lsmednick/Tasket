package edu.neu.madcourse.tasket;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.bignerdranch.expandablerecyclerview.Model.ParentObject;

import java.util.ArrayList;

public class ViewTeams extends AppCompatActivity {

    private RecyclerView myRecycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_teams);

        myRecycler = findViewById(R.id.teamNameRecyclerView);
        
    }

    private ArrayList<ParentObject> generateTeam(){

    }
}